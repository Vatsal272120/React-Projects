import React, { useState } from "react";
import { Link } from "react-router-dom";
import vatsal from "../assets/v.png";
import "../stylesheets/Header.css";

const Header = () => {
  return (
    <div className="header">
      <div className="header__icons">
        <div className="header__icon">
          <Link className="home__active" to="/">
            {" "}
            <p> Home</p>
          </Link>
        </div>
        <div className="header__icon">
          <Link to="/about">
            {" "}
            <p> About</p>
          </Link>
        </div>
        <div className="header__icon">
          <Link to="/work">
            {" "}
            <p>Work</p>
          </Link>
        </div>
        <div className="header__icon">
          <Link to="/contact">
            {" "}
            <p>Contact</p>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Header;
