import React, { forwardRef } from "react";
import "../stylesheets/ProjectCard.css";
import GitHubIcon from "@material-ui/icons/GitHub";
import LiveTvRoundedIcon from "@material-ui/icons/LiveTvRounded";
import spotify from "../assets/Spot.jpg";

const ProjectCard = ({ title, image, overview, github, live }) => {
  return (
    <div className="projectCard">
      <img src={image} alt="name" />

      <h2>{title}</h2>
      <p className="projectCard__stats">
        {overview} <br />
        <a href={github} target="_blank">
          <GitHubIcon /> {""}
        </a>
        <a href={live} target="_blank">
          <LiveTvRoundedIcon /> {""}
        </a>
      </p>
    </div>
  );
};

export default ProjectCard;
