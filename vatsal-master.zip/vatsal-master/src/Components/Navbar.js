import React from "react";
import "../stylesheets/Navbar.css";

const Navbar = ({ click, and }) => {
  return (
    <div className="nav">
      <h2 style={{ fontSize: "bold" }} onClick={and}>
        {" "}
        ReactJS Projects{" "}
      </h2>
      <h2 style={{ fontSize: "bold" }} onClick={click} className="python">
        {" "}
        Full Stack Projects
      </h2>

      <h2 className="python">Python Projects</h2>
    </div>
  );
};

export default Navbar;
