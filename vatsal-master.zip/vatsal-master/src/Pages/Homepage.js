import React, { useState } from "react";

import Gitnub from "../assets/github.png";
import LinkedIn from "../assets/LI-In-Bug.png";
import "../stylesheets/Homepage.css";
import Footer from "../Components/Footer";

const Homepage = () => {
  const [home, sethome] = useState({
    title: "Vatsal Patel",
    subTitle: "Be Relentless",
    text: " Web Developer",
    img:
      "https://t3.ftcdn.net/jpg/01/10/50/08/240_F_110500828_sxjk3CHFm4GXditObd7V6dVyk3zLpYZX.jpg",
  });
  return (
    <div className="homepage">
      <div className="Title">
        <h1 className="title__name"> {home.title}</h1>

        <h2 className="title__lastName"> {home.text}</h2>
        <div className="title__links">
          <a href="https://github.com/Vatsal272120" target="_blank">
            <img classname="github" src={Gitnub} alt="" />
          </a>
          <a
            href="https://www.linkedin.com/in/vatsal-patel-aa1060136/"
            target="_blank"
          >
            <img classname="linkedin" src={LinkedIn} alt="" />
          </a>
        </div>
      </div>
    </div>
  );
};

export default Homepage;
