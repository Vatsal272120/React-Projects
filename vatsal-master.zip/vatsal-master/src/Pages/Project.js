import React, { useState } from "react";

import "../stylesheets/Project.css";
import ProjectCard from "./../Components/ProjectCard";
import Netflix from "../assets/Netflix.jpg";
import Covid from "../assets/covid.jpg";
import Navbar from "./../Components/Navbar";

const Project = () => {
  const [projects, setProject] = useState([
    {
      Id: 0,
      title: "Spotify-Clone",
      image:
        "https://imgix.bustle.com/uploads/image/2018/10/5/32a337c4-a6e9-4c0e-b512-010bb98e0049-spotify-logo.png?w=1020&h=574&fit=crop&crop=faces&auto=format%2Ccompress&cs=srgb&q=70",
      overview:
        "A spotify-clone made in React-JS with spotify's authentication and music API",
      github: "https://github.com/Vatsal272120/Spotify-clone",
      live: "",
    },
    {
      Id: 1,
      title: "Hulu-Clone",
      image:
        "https://press.hulu.com/wp-content/uploads/2020/02/hulu-digital-grnblk.png?w=2048",
      overview: "Cloned Hulu with movies pulling in from the TMDB's API",
      github: "https://github.com/Vatsal272120/Hulu-Clone",
      live: "",
    },
    {
      Id: 2,
      title: "Netlfix-Clone",
      image:
        "https://www.sacbee.com/latest-news/1mxqp0/picture242910646/alternates/FREE_1140/AP19165551810863.jpg",

      overview: "Cloned Netlfix using the TMDB API. Made in React",
      github: "https://github.com/Vatsal272120/MoviesNow",
      live: "",
    },
    {
      Id: 4,
      title: "Covid-Tracker",
      image:
        "https://thumbs-prod.si-cdn.com/bvysf4t6oPfkpAfd7TJ0DBUaNX8=/800x600/filters:no_upscale()/https://public-media.si-cdn.com/filer/79/4a/794a7e74-8c99-4fde-abcd-a303bc302ba1/sars-cov-19.jpg",
      overview:
        "Covid-19 Tracker for live tracking of Worldwide cases, with National Stats",
      github: "https://github.com/Vatsal272120/Hulu-Clone",
      live: "",
    },
  ]);

  const yoo = (e) => {
    setProject([
      {
        Id: 4,
        title: "Facebook-Clone",
        image:
          "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAT4AAACfCAMAAABX0UX9AAAAwFBMVEX///8YePMHc/RuoPT///0XePQAcfMAbfSow/kZd/UAbvHq8PwAb/UYePH///v//v/U4/K90vgYeO4AbvkAa+kAc/qavfUAdOsVevJSkPAMduoAZ/VKi+oSefoRdPjx9vy+0vCnwvFWkeLk7ftzovDF2PrZ5fpgmPBBhvPj6/cYeulAiuyIq+9xo+/m8vc5heyyyeyCrPigvu1/ofLJ3PK50uqQt/VCkeaLs+fY6vVfmfV8sPClx+eau/W30fRom/5PacvvAAAHPElEQVR4nO2dfV/aOhTH25A0pjbtaAGhykPVgRYGqLh7vU97/+9qQb0TaklTkMal5/uHmzD49Px28nRycmJZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAvzXB7biZnAiS5vg20P00vxF4vLy7iKnntFxH4LYcj8YXd8sx1v1kn595MjmLXGITm9sEEfv5h/irTTz3bJLMdT/fZ+a0c0NdxghhAsJI1xZ0X3/rDghz6E3nVPdTfk7wqBd5zC6AOVFvBK04i5+Ezlnc7RbJZ8c89OIEBNwEJ8SxRaNFhd7XZ32bMYeAgG+MQrbWjayHiAII52IoEd1h+Kj7qT8Jp72oHRbqllExbEc9GEREu70/j4VLFbbabZj4RHx+X/sWPFxEYV9MS3g5+bj4SD+MpkPdz6+XkZjRlRNuE0Lsr7ot0EnHRcWjhUQ+G7kd3Tbo4zoSk5WSzXYTLtYn0TfdVmgCXxYvMoph3mUtB5Bg0f4A9YR+7Wkd41kLxA/o9t7gHC1021I5+GJwQKeXEXBwUbf2e9k+ZMzIyEfal7rtqZaZd8iEJQux6Uy3RVWypExRPtblwk0R8iJPQD3XQevwM4/JxrhDbEaXum2qjjFVHnM5Y26UPnQev1xdXd2OV4/L79/+CM9pPyszHeu2qjJSlrV+t/fR9H7uW/h/fDHqWJZ/z+zt/4E+S3VbVRXXiCkFqAjpeumjEGytnvXyx1pB8UuTbg88JGTOtWazKuKrq+h5hEd/+r6VNylpeu/1d+sRPghVOz7mrEQ79f2c78iTj8WVm6KBGVJ1PvLk+zjwVb2PoBrMXk5bxftBz4T0y+5vyfU+1DI/fD9pc6XlBnOTvFb7Sp58nLcb1dmhh7Eb20rehy4k6uV7Hw9d0yd/E8YU9jUGKXPnuUPuK7nexxiaVGeJDm7fLRdyYeHgL9+XhPHy5BOQ6LY6WzRwrRZm4Txa+VjmffnLvpA8VGdL9QxdptTxiW7MynoffnkhCNY/m05uyIGRlsmR58RRi/Jx7+93nxXiiRXI6xJu5LEw73MDJ6neqsq4Iaw4h2otA32fwSKWH+PkrvFCz+7mdaIpim80mFURt247HajIh+g82/FhfzVtMcTQMyQ/XojCATV38Og4KtoJ2Nm2eoFwvX8ipW7TMXfffKrkemv5FtuTPrHyXZ2vczKKGUx1WXdshq7q/oaY/m6tOTD2b5jaoE1cU9OGRp7q5hpqbE/6An8cqe4Ke6bmTc7U/OdFvq1PYuteOczFTA1b3Sgno2Xls/Cd8r4mM3TqEiDlJMisfIF/rep9YtQ2c+FxFSlnML/3voZy4w2jKz32HRkxcuzb95WQj9neSIt5x6aDDuj71L2PITMnzjOElBa8h8nXRexOj31HZqLc+x8in3A/M0POvUFcRd8XIjOXbSlSzug7xPs4MjPbxVU/wnFY43X12HdkaIFkzht0kpVvQjfeduRaUj32HZlIrt73kw2aWfmam++eJFL9Ij32HRmp9xH3SfmLfGsuTdIy0/ukfR9xJRktGXy8kshnat8nHXlLyecvJVF/U0de6byvhHwYy5LcjJ33SVcd5eSTfZWpqw7pmrdM48U43e3Gxq55pRGXMvJZAZV8kakRF2m8r5R8T+7uLzI23ndFJdHmUo23KdnxNDbaLN3rKCXfv7JsBVP3OqzFB/V9+JtsDDd1p026z1tq2nwjOU9o7j6vNMvA25QPB9mQweYLvicL+hubZSDLceHRE95kO7U02Hpv3mrvVs/cHBdZhhWhj6cbzINMhtX87b3hf166W77BhS7rjo4sv6/rtiL6i0nmUIc/eXuPepzs7kQNzu+TZpduZu/tG6w3O7tUObd5X/nMzm1WzqzfVz7DM+uHLaLWCPeUz/BzHdY1yTuO8WHyGX6qyLqKlPZ695XP9DNt1gSpnKjcS74anKhUPM+7l3x1OM+rdpp8P++rwWlytVoG+3lfHWoZWDOFRKv9ho46VNJQquOyn/fVoo6LShWhveSrSRWh5xpWHy1f2K9LDSvLSklBQYjy8vVJWpsCnIX1+8rLR6iZ25O5FFWPLClfzapHFtYuLS1fvWqXrivnypa+5eSrX+XcgrrNJeWrX91mC8uqhpeRj3O2qJ16lhVMd9esLyMfay+MjjDvQnJjQgn56npjgiW5r0NVPlbj+zqs3bfFKMpX89tiLGuUX9tGVT5mj3Q89edhOI3CPsnelFUo3+tNWT1j04FUebmnLdOEC+Vb3xQYn5u8Ja7MvEfbmfGjWD7epnBL4CuP4foi4407KnfLt3a7538RrvQ862cEJ8TbvCF1t3wMiY7S9my4IXULnKQO/3U/7275ut2YOymI9w486lGv2Ps8CrdD7+C0s6DO+h7yuIG30kt93IjFy8yhi5Paz1VkzJPGWeQ4PzKp4f4Px4nOGgloVwgeLx9mWflmD8sxtFkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIB68hMLKHhuW0jeAAAAAABJRU5ErkJggg==",
        overview: "Facebook-Clone made in ReactJS",
        github: "https://github.com/Vatsal272120/Facebook-Clone",
        live: "",
      },
      ,
    ]);
  };

  const noo = () => {
    setProject([
      {
        Id: 0,
        title: "Spotify-Clone",
        image:
          "https://imgix.bustle.com/uploads/image/2018/10/5/32a337c4-a6e9-4c0e-b512-010bb98e0049-spotify-logo.png?w=1020&h=574&fit=crop&crop=faces&auto=format%2Ccompress&cs=srgb&q=70",
        overview:
          "A spotify-clone made in React-JS with spotify's authentication and music API",
        github: "https://github.com/Vatsal272120/Spotify-clone",
        live: "",
      },
      {
        Id: 1,
        title: "Hulu-Clone",
        image:
          "https://press.hulu.com/wp-content/uploads/2020/02/hulu-digital-grnblk.png?w=2048",
        overview: "Cloned Hulu with movies pulling in from the TMDB's API",
        github: "https://github.com/Vatsal272120/Hulu-Clone",
        live: "",
      },
      {
        Id: 2,
        title: "Netlfix-Clone",
        image:
          "https://www.sacbee.com/latest-news/1mxqp0/picture242910646/alternates/FREE_1140/AP19165551810863.jpg",

        overview: "Cloned Netlfix using the TMDB API. Made in React",
        github: "https://github.com/Vatsal272120/MoviesNow",
        live: "",
      },
      {
        Id: 4,
        title: "Covid-Tracker",
        image:
          "https://thumbs-prod.si-cdn.com/bvysf4t6oPfkpAfd7TJ0DBUaNX8=/800x600/filters:no_upscale()/https://public-media.si-cdn.com/filer/79/4a/794a7e74-8c99-4fde-abcd-a303bc302ba1/sars-cov-19.jpg",
        overview:
          "Covid-19 Tracker for live tracking of Worldwide cases, with National Stats",
        github: "https://github.com/Vatsal272120/Hulu-Clone",
        live: "",
      },
    ]);
  };

  return (
    <div className="work">
      <h1> </h1>
      <Navbar click={yoo} and={noo} />

      <div className="project">
        {projects.map((project) => (
          <ProjectCard
            key={project.id}
            title={project.title}
            image={project.image}
            overview={project.overview}
            github={project.github}
            live={project.live}
          />
        ))}
      </div>
    </div>
  );
};

export default Project;
