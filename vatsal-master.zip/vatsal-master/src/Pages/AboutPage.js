import React from "react";

import Content from "../Components/Content";
import "../stylesheets/Aboutpage.css";

const AboutPage = () => {
  return (
    <div className="about">
      <div className="Title">
        <h1 className="about__title"> About Me</h1>
      </div>
      <Content>
        <p>
          Hello, my name is Vatsal. I am a Full-Stack Software Developer that
          possesses the skills to be a part of a team and also thrives on
          getting the job done accurately and efficiently.
        </p>

        <p>
          What I continue to learn and love about software engineering is that
          there is no end. There are always ways to continue to learn new
          techniques and languages while evolving those skills to become a
          better web developer.
        </p>
        <p>
          As a lifelong athlete, I have gained strong skills in teamwork,
          collaboration, and being coachable to increase effectiveness.
          Experienced member in React-JS, React-Native, NodeJS JavaScript, HTML,
          CSS, Mongo-DB, Pair-Programming, Object-Oriented Programing
        </p>
        <p>
          I like to resolve design problems, create a smart user interface, and
          imagine useful interaction, developing rich web experiences and web
          applications. When not working or futzing around with code, I like to
          passionately learn and preach facts about beer.
        </p>
      </Content>
    </div>
  );
};

export default AboutPage;
