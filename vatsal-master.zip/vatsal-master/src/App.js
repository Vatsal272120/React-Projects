import React from "react";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";

import "./App.css";
//import "./stylesheets/Header.css";

import "./App.css";
import Homepage from "./Pages/Homepage";
import AboutPage from "./Pages/AboutPage";
import ContactPage from "./Pages/ContactPage";
import Header from "./Components/Header";

import Project from "./Pages/Project";
import Navbar from "./Components/Navbar";

function App() {
  return (
    <div className="app">
      <Router>
        <Header />
        <Switch>
          <Route path="/contact">
            <ContactPage />
          </Route>
          <Route path="/work">
            <Project />
          </Route>
          <Route path="/about">
            <AboutPage />
          </Route>
          <Route path="/">
            <Homepage />
          </Route>
        </Switch>
      </Router>
    </div>
  );
}

export default App;

/* <Router>
  <Container className="p-0" fluid={true}>
    <Navbar className="border-bottom" bg="transparent" expand="lg">
      <Navbar.Brand>Garrett Love</Navbar.Brand>

      <Navbar.Toggle className="border-0" aria-controls="navbar-toggle" />
      <Navbar.Collapse id="navbar-toggle">
        <Nav className="ml-auto">
          <Link className="nav-link" to="/">
            Home
          </Link>
          <Link className="nav-link" to="/about">
            About
          </Link>
          <Link className="nav-link" to="/contact">
            Contact
          </Link>
        </Nav>
      </Navbar.Collapse>
    </Navbar>

    <Route path="/" exact render={() => <HomePage />} />
    <Route path="/about" render={() => <AboutPage />} />
    <Route path="/contact" render={() => <ContactPage />} />

    <Footer />
  </Container>
</Router>;

<div className="App">
  <Router>
    <Switch>
      {/* <Route path="/work">
            <Header />
            <Project />
          </Route> */

/*   <Route path="/contact">
        <Header />
        <ContactPage />
      </Route>
      <Route path="/about">
        <Header />
        <AboutPage />
      </Route>
      <Route path="/">
        <Header />
        <Homepage />
      </Route>
    </Switch>
  </Router>
</div>;
 */
