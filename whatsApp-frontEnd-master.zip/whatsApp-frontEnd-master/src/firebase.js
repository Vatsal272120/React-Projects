// For Firebase JS SDK v7.20.0 and later, measurementId is optional
import firebase from "firebase";

const firebaseConfig = {
  apiKey: "AIzaSyB6NpOZQwl3P8tWTOWcrneNarATlTMnzVk",
  authDomain: "whatsapp-mern-a957b.firebaseapp.com",
  databaseURL: "https://whatsapp-mern-a957b.firebaseio.com",
  projectId: "whatsapp-mern-a957b",
  storageBucket: "whatsapp-mern-a957b.appspot.com",
  messagingSenderId: "484089308369",
  appId: "1:484089308369:web:75131abe70bae85afd11f0",
  measurementId: "G-Q5ZFJ6BN1L",
};

const firebaseApp = firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const provider = new firebase.auth.GoogleAuthProvider();

export { auth, provider };
