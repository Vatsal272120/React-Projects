import React from "react";
import "../StyleSheets/SidebarChat.css";
import { Avatar } from "@material-ui/core";

const SidebarChats = ({ addNewChat }) => {
  const createChat = () => {
    const roomName = prompt("enter the name for chat");

    if (roomName) {
      // db
    }
  };

  return !addNewChat ? (
    <div className="sidebarChat">
      <Avatar src="https://avatars0.githubusercontent.com/u/63895925?s=460&u=4198c14ba7fd36dfdba5d3c89227741557fab822&v=4" />
      <div className="sidebaChat__info">
        <h2> Room Name</h2>
        <p> last message ..</p>
      </div>
    </div>
  ) : (
    <div onClick={createChat} className="sidebarChat">
      <h2> Add New Chat</h2>
    </div>
  );
};

export default SidebarChats;
