import React from "react";
import "./App.css";
import Sidebar from "./Components/Sidebar";
import Chats from "./Components/Chats";

function App() {
  return (
    <div className="app">
      <div className="app__body">
        <Sidebar />
        <Chats />
      </div>
    </div>
  );
}

export default App;
