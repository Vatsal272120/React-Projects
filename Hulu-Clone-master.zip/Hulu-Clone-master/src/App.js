import React, { useState } from "react";
import "./App.css";

//Components
import Header from "./Components/Header";
import Navbar from "./Components/Navbar";
import Results from "./Components/Results";
// utils

import requests from "./Utils/request";

function App() {
  const [selectedOption, setselectedOption] = useState(requests.fetchTrending);
  return (
    <div className="app">
      <Header />
      <Navbar setselectedOption={setselectedOption} />
      <Results selectedOption={selectedOption} />
    </div>
  );
}

export default App;
