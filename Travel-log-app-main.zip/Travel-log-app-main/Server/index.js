import express from "express";
import morgan from "morgan";
import cors from "cors";
import helmet from "helmet";
import errorhandler from "errorhandler";

const app = express();

// middleware
app.use(express.json());
app.use(morgan("common"));
app.use(helmet());

// error handler

if (process.env.NODE_ENV === "development") {
  // only use in development
  app.use(errorhandler({ log: errorNotification }));
}

const errorNotification = (err, str, req) => {
  const title = "Error in " + req.method + " " + req.url;

  notifier.notify({
    title: title,
    message: str,
  });
};

// api route : checker
app.get("/", (req, res) => {
  res.status(201).send("Hello");
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`app running on ${PORT}`);
});
