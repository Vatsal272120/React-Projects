import mongoose from "mongoose";

// schema

const requiredNumber = {
  type: Number,
  required: true,
};

const logEntrySchema = mongoose.Schema({
  title: {
    type: String,
    required: true,
  },

  description: String,

  comments: String,
  image: String,
  rating: {
    type: Number,
    min: 0,
    max: 10,
    default: 0,
  },

  latitude: {
    ...requiredNumber,
    min: -90,
    max: 90,
  },
  longitude: {
    ...requiredNumber,
    min: -180,
    max: 180,
  },
  visitDate: {
    required: true,
    type: Date,
  },
});

export default mongoose.model("logEntry", logEntrySchema);
