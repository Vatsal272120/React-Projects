const mongoose = require('mongoose');
const validator = require('validator');
const bcrypt = require('bcryptjs'); // password hashing
const jwt = require('jsonwebtoken'); // web tokens

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true,
  },

  age: {
    type: Number,
    default: true,
    required: true,
    validate(value) {
      if (value < 0) {
        throw new Error(` age must be a valid number and not ${value}`);
      }
    },
  },

  email: {
    type: String,
    unique: true, // uniqueness to email
    required: true,
    trim: true,
    lowercase: true,
    validator(value) {
      if (!validator.isEmail(value)) {
        throw new Error(`please enter a valid email`);
      }
    },
  },

  password: {
    type: String,
    required: true,
    minlength: 9,
    trim: true,
    validator(value) {
      if (value.toLowerCase().includes(`password`)) {
        throw new Error(` password cannot be password`);
      }
    },
  },

  tokens: [
    {
      token: {
        type: String,
        required: true,
      },
    },
  ],
});

// generating token [ using .methods -> creating a method for an INSTANCE OF THE USER MODEL] methods are accessible on the instace -> instance methods
userSchema.methods.generateAuthToken = async function () {
  const user = this;
  const token = jwt.sign({ _id: user._id.toString() }, 'secretkey');

  user.tokens = user.tokens.concat({ token });
  await user.save();

  return token;
};

//Logging in User [ using .statics -> creating a method for the whole USER MODEL]  statics are accesible onto the model -> model methods
userSchema.statics.logIn = async (email, password) => {
  // user log in - finds by email - true (pass match and return)
  const user = await User.findOne({ email });
  if (!user) {
    throw new Error('unable to log In');
  }
  const isMatch = await bcrypt.compare(password, user.password);

  if (!isMatch) {
    throw new Error('unable to log In');
  }

  return user;
};

// fn will run before the user is created or saved

userSchema.pre('save', async function (next) {
  const user = this;

  if (user.isModified('password')) {
    user.password = await bcrypt.hash(user.password, 8);
  }

  next();
});

// User Model
const User = mongoose.model('User', userSchema);

module.exports = User;
