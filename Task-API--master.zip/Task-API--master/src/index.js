const express = require('express');
const port = process.env.PORT || 3000;
require('./db/mongoose');
const userRouter = require('./routers/user');
const taskRouter = require('./routers/task');

// enabling app
const app = express();

//parsing Json to js object
app.use(express.json());

// registering routers with the app
app.use(userRouter);
app.use(taskRouter);

// starting up the server
app.listen(port, () => {
  console.log(`server up on port:${port}`);
});
