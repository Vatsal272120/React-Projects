import firebase from "firebase";

const firebaseConfig = {
  apiKey: "AIzaSyCKhpwsCaPH3_MH4KmKT7PoBDPZ5FnGDZY",
  authDomain: "slack-clone-3e726.firebaseapp.com",
  databaseURL: "https://slack-clone-3e726.firebaseio.com",
  projectId: "slack-clone-3e726",
  storageBucket: "slack-clone-3e726.appspot.com",
  messagingSenderId: "227456638036",
  appId: "1:227456638036:web:2de6c4f670fb65144d61c1",
  measurementId: "G-X4LN6WWMBF",
};

// real-time datbase
const firebaseApp = firebase.initializeApp(firebaseConfig);
const db = firebaseApp.firestore();

//authentication by google
const auth = firebase.auth();
const provider = new firebase.auth.GoogleAuthProvider();

export { auth, provider };
export default db;
