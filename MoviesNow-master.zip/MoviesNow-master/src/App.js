import React from "react";
import "./App.css";
import Row from "./Components/Row";
import requests from "./Utils/request";
import Navbar from "./Components/Navbar";
import Banner from "./Components/Banner";

function App() {
  return (
    <div className="app">
      {/* Nav */}
      <Navbar />
      {/* Banner */}
      <Banner fetchUrl={requests.fetchTopRated} />

      {/* Rows */}
      <Row
        title="Netflix Originals"
        fetchUrl={requests.fetchNetflixOriginals}
      />
      <Row title="Trending Now" fetchUrl={requests.fetchTrending} />
      <Row title="Top Rated" fetchUrl={requests.fetchTopRated} />
      <Row title="Action" fetchUrl={requests.fetchActionMovies} />
      <Row title="Comedies" fetchUrl={requests.fetchComedyMovies} />
      <Row title="Horror" fetchUrl={requests.fetchHorrorMovies} />
      <Row title="Romance" fetchUrl={requests.fetchRomanceMovies} />
      <Row title="Documentaries" fetchUrl={requests.fetchDocumentaries} />
      <Row title="Popular" fetchUrl={requests.fetchPopular} />
      <Row title="Now Playing" fetchUrl={requests.fetchNowPlaying} />
    </div>
  );
}

export default App;
