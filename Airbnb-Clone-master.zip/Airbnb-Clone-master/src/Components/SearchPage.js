import React from "react";
import "../Stylesheets/SearchPage.css";
const SearchPage = () => {
  return <div></div>;
};

export default SearchPage;
