import firebase from "firebase";

const firebaseConfig = {
  apiKey: "AIzaSyB-YzbMEp2uOod_GaAtq9TZJZEEe8Pgf1Y",
  authDomain: "twitter-629f4.firebaseapp.com",
  databaseURL: "https://twitter-629f4.firebaseio.com",
  projectId: "twitter-629f4",
  storageBucket: "twitter-629f4.appspot.com",
  messagingSenderId: "397340109080",
  appId: "1:397340109080:web:2f1d4721837c0d89da966d",
  measurementId: "G-LCCFRM7DBC",
};

const firebaseApp = firebase.initializeApp(firebaseConfig);
const db = firebaseApp.firestore();
export default db;
