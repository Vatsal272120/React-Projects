import { Avatar, Button } from "@material-ui/core";
import React, { useState } from "react";
import "../Styles/TweetBox.css";
import db from "./../firebase";

const TweetBox = () => {
  const [tweetMessage, setTweetMessage] = useState("");
  const [tweetImage, setTweetImage] = useState("");

  const tweet = (e) => {
    e.preventDefault();

    db.collection("posts").add({
      displayName: "Vatsal Patel",
      userName: "v.at.sa.l",
      verified: true,

      text: tweetMessage,
      avatar:
        "https://scontent.famd4-1.fna.fbcdn.net/v/t1.0-9/60273357_2561771940560434_7436833970077040640_n.jpg?_nc_cat=109&_nc_sid=84a396&_nc_ohc=-TZZdqTc_oYAX_8Dqnj&_nc_ht=scontent.famd4-1.fna&oh=1a9d1da73ca3520b9ea1f6ce90208a76&oe=5F93F839",
      img: tweetImage,
    });

    setTweetMessage("");
    setTweetImage("");
  };

  return (
    <div className="tweetBox">
      <form action="submit">
        <div className="tweetBox__input">
          <Avatar src="https://scontent.famd4-1.fna.fbcdn.net/v/t1.0-9/60273357_2561771940560434_7436833970077040640_n.jpg?_nc_cat=109&_nc_sid=84a396&_nc_ohc=-TZZdqTc_oYAX_8Dqnj&_nc_ht=scontent.famd4-1.fna&oh=1a9d1da73ca3520b9ea1f6ce90208a76&oe=5F93F839" />

          <input
            value={tweetMessage}
            onChange={(e) => setTweetMessage(e.target.value)}
            className=".tweetBox__input"
            placeholder="What's happening"
            type="text"
          />
        </div>
        <input
          value={tweetImage}
          onChange={(e) => setTweetImage(e.target.value)}
          className="tweetBox__imageInput "
          placeholder="Optional: Enter Image URL"
          type="text"
        />

        <Button className="tweetBox__tweetButton" type="submit" onClick={tweet}>
          {" "}
          Tweet
        </Button>
      </form>
    </div>
  );
};

export default TweetBox;
