import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import dbModel from "./dbModel.js";
import Pusher from "pusher";

// app config
const app = express();
const PORT = process.env.PORT || 3001;

//app middlewares
app.use(express.json());
app.use(cors());

//db config
const connectionURL = `mongodb+srv://vatsal:BF2wb9QQabTNSVDP@cluster0.okxhm.mongodb.net/insta?retryWrites=true&w=majority`;
mongoose.connect(connectionURL, {
  useCreateIndex: true,
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

mongoose.connection.on("open", () => console.log(`db connected`));

// api route

// img upload
app.post("/upload", (req, res) => {
  const body = req.body;

  dbModel
    .create(body)
    .then((data) => res.status(201).send(data))
    .catch((e) => res.status(500).send(e));
});

// img render
app.get("/sync", (req, res) => {
  dbModel
    .find()
    .then((data) => res.status(201).send(data))
    .catch((e) => res.status(500).send(e));
});

app.get("/", (req, res) => {
  res.status(200).send("Hello World");
});

//listen
app.listen(PORT, () => {
  console.log(`app on ${PORT}`);
});
