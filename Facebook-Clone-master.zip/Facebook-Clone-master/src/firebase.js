import firebase from "firebase";

const firebaseConfig = {
  apiKey: "AIzaSyC9_VzPtePtLC7g4jb09EEGsMgsKw-7GI8",
  authDomain: "facebook-36f92.firebaseapp.com",
  databaseURL: "https://facebook-36f92.firebaseio.com",
  projectId: "facebook-36f92",
  storageBucket: "facebook-36f92.appspot.com",
  messagingSenderId: "715660741",
  appId: "1:715660741:web:1e1749303ff2220215ffac",
  measurementId: "G-LYSHV3T77G",
};
const firebaseApp = firebase.initializeApp(firebaseConfig); //connect the frontend to backend
const db = firebaseApp.firestore(); // database access
const auth = firebase.auth(); // setup auth
const provider = new firebase.auth.GoogleAuthProvider(); // auth provider

export { auth, provider };
export default db;
