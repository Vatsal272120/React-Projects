import firebase from 'firebase';

const firebaseConfig = {
  apiKey: 'AIzaSyB85I6g5xAAyAoofKMxS-EmGweuVCRtPFw',
  authDomain: 'tinder-clone-2a691.firebaseapp.com',
  databaseURL: 'https://tinder-clone-2a691.firebaseio.com',
  projectId: 'tinder-clone-2a691',
  storageBucket: 'tinder-clone-2a691.appspot.com',
  messagingSenderId: '919278515452',
  appId: '1:919278515452:web:3e37399891f6d246499379',
  measurementId: 'G-CDJCNJYM3Z',
};

const firebaseApp = firebase.initializeApp(firebaseConfig);
const database = firebaseApp.firestore();

export default database;
